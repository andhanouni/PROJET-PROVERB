-- phpMyAdmin SQL Dump
-- version 4.6.2
-- https://www.phpmyadmin.net/
--
-- Client :  localhost
-- Généré le :  Ven 07 Avril 2017 à 14:44
-- Version du serveur :  5.7.13
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `spip_CDNL1617_proverbe`
--

-- --------------------------------------------------------

--
-- Structure de la table `spip_articles`
--

DROP TABLE IF EXISTS `spip_articles`;
CREATE TABLE `spip_articles` (
  `id_article` bigint(21) NOT NULL,
  `surtitre` text NOT NULL,
  `titre` text NOT NULL,
  `soustitre` text NOT NULL,
  `id_rubrique` bigint(21) NOT NULL DEFAULT '0',
  `descriptif` text NOT NULL,
  `chapo` mediumtext NOT NULL,
  `texte` longtext NOT NULL,
  `ps` mediumtext NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `statut` varchar(10) NOT NULL DEFAULT '0',
  `id_secteur` bigint(21) NOT NULL DEFAULT '0',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `export` varchar(10) DEFAULT 'oui',
  `date_redac` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visites` int(11) NOT NULL DEFAULT '0',
  `referers` int(11) NOT NULL DEFAULT '0',
  `popularite` double NOT NULL DEFAULT '0',
  `accepter_forum` char(3) NOT NULL DEFAULT '',
  `date_modif` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lang` varchar(10) NOT NULL DEFAULT '',
  `langue_choisie` varchar(3) DEFAULT 'non',
  `id_trad` bigint(21) NOT NULL DEFAULT '0',
  `nom_site` tinytext NOT NULL,
  `url_site` text NOT NULL,
  `virtuel` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_auteurs`
--

DROP TABLE IF EXISTS `spip_auteurs`;
CREATE TABLE `spip_auteurs` (
  `id_auteur` bigint(21) NOT NULL,
  `nom` text NOT NULL,
  `bio` text NOT NULL,
  `email` tinytext NOT NULL,
  `nom_site` tinytext NOT NULL,
  `url_site` text NOT NULL,
  `login` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `pass` tinytext NOT NULL,
  `low_sec` tinytext NOT NULL,
  `statut` varchar(255) NOT NULL DEFAULT '0',
  `webmestre` varchar(3) NOT NULL DEFAULT 'non',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pgp` text NOT NULL,
  `htpass` tinytext NOT NULL,
  `en_ligne` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `alea_actuel` tinytext,
  `alea_futur` tinytext,
  `prefs` tinytext,
  `cookie_oubli` tinytext,
  `source` varchar(10) NOT NULL DEFAULT 'spip',
  `lang` varchar(10) NOT NULL DEFAULT '',
  `imessage` varchar(3) DEFAULT NULL,
  `messagerie` varchar(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `spip_auteurs`
--

INSERT INTO `spip_auteurs` (`id_auteur`, `nom`, `bio`, `email`, `nom_site`, `url_site`, `login`, `pass`, `low_sec`, `statut`, `webmestre`, `maj`, `pgp`, `htpass`, `en_ligne`, `alea_actuel`, `alea_futur`, `prefs`, `cookie_oubli`, `source`, `lang`, `imessage`, `messagerie`) VALUES
(1, 'Samuel Szoniecky', '', 'samuel.szoniecky@univ-paris8.fr', '', '', 'samszo', 'de4ec71b386d7b0207c63dbbc473aea8a62d4a1ae5be412aeec432fcf028c802', '', '0minirezo', 'oui', '2017-04-07 12:43:28', '', '$1$nHWo4Mnj$kCt1hHKBwCVtbwDltlsNl.', '2017-04-07 14:43:28', '5850263358e7896dbd15d6.20896964', '63066084358e7896dc058c4.35283498', 'a:5:{s:7:"couleur";i:9;s:7:"display";i:2;s:18:"display_navigation";s:22:"navigation_avec_icones";s:14:"display_outils";s:3:"oui";s:3:"cnx";s:0:"";}', NULL, 'spip', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `spip_auteurs_liens`
--

DROP TABLE IF EXISTS `spip_auteurs_liens`;
CREATE TABLE `spip_auteurs_liens` (
  `id_auteur` bigint(21) NOT NULL DEFAULT '0',
  `id_objet` bigint(21) NOT NULL DEFAULT '0',
  `objet` varchar(25) NOT NULL DEFAULT '',
  `vu` varchar(6) NOT NULL DEFAULT 'non'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_breves`
--

DROP TABLE IF EXISTS `spip_breves`;
CREATE TABLE `spip_breves` (
  `id_breve` bigint(21) NOT NULL,
  `date_heure` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `titre` text NOT NULL,
  `texte` longtext NOT NULL,
  `lien_titre` text NOT NULL,
  `lien_url` text NOT NULL,
  `statut` varchar(6) NOT NULL DEFAULT '0',
  `id_rubrique` bigint(21) NOT NULL DEFAULT '0',
  `lang` varchar(10) NOT NULL DEFAULT '',
  `langue_choisie` varchar(3) DEFAULT 'non',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_depots`
--

DROP TABLE IF EXISTS `spip_depots`;
CREATE TABLE `spip_depots` (
  `id_depot` bigint(21) NOT NULL,
  `titre` text NOT NULL,
  `descriptif` text NOT NULL,
  `type` varchar(10) NOT NULL DEFAULT '',
  `url_serveur` varchar(255) NOT NULL DEFAULT '',
  `url_brouteur` varchar(255) NOT NULL DEFAULT '',
  `url_archives` varchar(255) NOT NULL DEFAULT '',
  `url_commits` varchar(255) NOT NULL DEFAULT '',
  `xml_paquets` varchar(255) NOT NULL DEFAULT '',
  `sha_paquets` varchar(40) NOT NULL DEFAULT '',
  `nbr_paquets` int(11) NOT NULL DEFAULT '0',
  `nbr_plugins` int(11) NOT NULL DEFAULT '0',
  `nbr_autres` int(11) NOT NULL DEFAULT '0',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_depots_plugins`
--

DROP TABLE IF EXISTS `spip_depots_plugins`;
CREATE TABLE `spip_depots_plugins` (
  `id_depot` bigint(21) NOT NULL,
  `id_plugin` bigint(21) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_documents`
--

DROP TABLE IF EXISTS `spip_documents`;
CREATE TABLE `spip_documents` (
  `id_document` bigint(21) NOT NULL,
  `id_vignette` bigint(21) NOT NULL DEFAULT '0',
  `extension` varchar(10) NOT NULL DEFAULT '',
  `titre` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `descriptif` text NOT NULL,
  `fichier` text NOT NULL,
  `taille` bigint(20) DEFAULT NULL,
  `largeur` int(11) DEFAULT NULL,
  `hauteur` int(11) DEFAULT NULL,
  `media` varchar(10) NOT NULL DEFAULT 'file',
  `mode` varchar(10) NOT NULL DEFAULT 'document',
  `distant` varchar(3) DEFAULT 'non',
  `statut` varchar(10) NOT NULL DEFAULT '0',
  `credits` varchar(255) NOT NULL DEFAULT '',
  `date_publication` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `brise` tinyint(4) DEFAULT '0',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_documents_liens`
--

DROP TABLE IF EXISTS `spip_documents_liens`;
CREATE TABLE `spip_documents_liens` (
  `id_document` bigint(21) NOT NULL DEFAULT '0',
  `id_objet` bigint(21) NOT NULL DEFAULT '0',
  `objet` varchar(25) NOT NULL DEFAULT '',
  `vu` enum('non','oui') NOT NULL DEFAULT 'non'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_forum`
--

DROP TABLE IF EXISTS `spip_forum`;
CREATE TABLE `spip_forum` (
  `id_forum` bigint(21) NOT NULL,
  `id_objet` bigint(21) NOT NULL DEFAULT '0',
  `objet` varchar(25) NOT NULL DEFAULT '',
  `id_parent` bigint(21) NOT NULL DEFAULT '0',
  `id_thread` bigint(21) NOT NULL DEFAULT '0',
  `date_heure` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_thread` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `titre` text NOT NULL,
  `texte` mediumtext NOT NULL,
  `auteur` text NOT NULL,
  `email_auteur` text NOT NULL,
  `nom_site` text NOT NULL,
  `url_site` text NOT NULL,
  `statut` varchar(8) NOT NULL DEFAULT '0',
  `ip` varchar(40) NOT NULL DEFAULT '',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_auteur` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_groupes_mots`
--

DROP TABLE IF EXISTS `spip_groupes_mots`;
CREATE TABLE `spip_groupes_mots` (
  `id_groupe` bigint(21) NOT NULL,
  `titre` text NOT NULL,
  `descriptif` text NOT NULL,
  `texte` longtext NOT NULL,
  `unseul` varchar(3) NOT NULL DEFAULT '',
  `obligatoire` varchar(3) NOT NULL DEFAULT '',
  `tables_liees` text NOT NULL,
  `minirezo` varchar(3) NOT NULL DEFAULT '',
  `comite` varchar(3) NOT NULL DEFAULT '',
  `forum` varchar(3) NOT NULL DEFAULT '',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_jobs`
--

DROP TABLE IF EXISTS `spip_jobs`;
CREATE TABLE `spip_jobs` (
  `id_job` bigint(21) NOT NULL,
  `descriptif` text NOT NULL,
  `fonction` varchar(255) NOT NULL,
  `args` longblob NOT NULL,
  `md5args` char(32) NOT NULL DEFAULT '',
  `inclure` varchar(255) NOT NULL,
  `priorite` smallint(6) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `spip_jobs`
--

INSERT INTO `spip_jobs` (`id_job`, `descriptif`, `fonction`, `args`, `md5args`, `inclure`, `priorite`, `date`, `status`) VALUES
(1, 'Tâche CRON queue_watch (toutes les 86400 s)', 'queue_watch', 0x613a313a7b693a303b643a313439313531333035343b7d, 'e8f8e1cbb5b29fb2ff78f2331eb36ca0', 'genie/', 0, '2017-04-07 14:43:25', 1),
(2, 'Tâche CRON optimiser (toutes les 172800 s)', 'optimiser', 0x613a313a7b693a303b643a313439313536333233373b7d, '10af521a2b1da6082298ab0d2397a294', 'genie/', 0, '2017-04-07 14:43:25', 1),
(3, 'Tâche CRON invalideur (toutes les 600 s)', 'invalideur', 0x613a313a7b693a303b643a313439313536383838323b7d, 'bb30c062b0b1c7d16254b928a360c8e0', 'genie/', 0, '2017-04-07 14:43:25', 1),
(4, 'Tâche CRON maintenance (toutes les 7200 s)', 'maintenance', 0x613a313a7b693a303b643a313439313536333234383b7d, 'b3fd6e15fc342e72a03381a91b1f0482', 'genie/', 0, '2017-04-07 14:43:25', 1),
(5, 'Tâche CRON mise_a_jour (toutes les 259200 s)', 'mise_a_jour', 0x613a313a7b693a303b643a313439313337393732343b7d, 'e5a3e84b9d2cbf238ac25ab844c4f81e', 'genie/', 0, '2017-04-07 14:43:25', 1),
(6, 'Tâche CRON optimiser_revisions (toutes les 86400 s)', 'optimiser_revisions', 0x613a313a7b693a303b643a313439313439373535363b7d, 'a15cdd17f8f6be975f0b7c1ab10425b3', 'genie/', 0, '2017-04-07 14:43:25', 1),
(7, 'Tâche CRON svp_actualiser_depots (toutes les 21600 s)', 'svp_actualiser_depots', 0x613a313a7b693a303b643a313439313536323934303b7d, '12303b330d4f7b1dcedfa2ae2618a8bd', 'genie/', 0, '2017-04-07 14:43:25', 1);

-- --------------------------------------------------------

--
-- Structure de la table `spip_jobs_liens`
--

DROP TABLE IF EXISTS `spip_jobs_liens`;
CREATE TABLE `spip_jobs_liens` (
  `id_job` bigint(21) NOT NULL DEFAULT '0',
  `id_objet` bigint(21) NOT NULL DEFAULT '0',
  `objet` varchar(25) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_messages`
--

DROP TABLE IF EXISTS `spip_messages`;
CREATE TABLE `spip_messages` (
  `id_message` bigint(21) NOT NULL,
  `titre` text NOT NULL,
  `texte` longtext NOT NULL,
  `type` varchar(6) NOT NULL DEFAULT '',
  `date_heure` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_fin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rv` varchar(3) NOT NULL DEFAULT '',
  `statut` varchar(6) NOT NULL DEFAULT '0',
  `id_auteur` bigint(21) NOT NULL DEFAULT '0',
  `destinataires` text NOT NULL,
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_meta`
--

DROP TABLE IF EXISTS `spip_meta`;
CREATE TABLE `spip_meta` (
  `nom` varchar(255) NOT NULL,
  `valeur` text,
  `impt` enum('non','oui') NOT NULL DEFAULT 'oui',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `spip_meta`
--

INSERT INTO `spip_meta` (`nom`, `valeur`, `impt`, `maj`) VALUES
('charset_sql_base', 'utf8', 'non', '2017-04-07 12:43:13'),
('charset_collation_sql_base', 'utf8_general_ci', 'non', '2017-04-07 12:43:13'),
('charset_sql_connexion', 'utf8', 'non', '2017-04-07 12:43:13'),
('version_installee', '21742', 'non', '2017-04-07 12:43:13'),
('nouvelle_install', '1', 'non', '2017-04-07 12:43:13'),
('langue_site', 'fr', 'non', '2017-04-07 12:43:25'),
('pcre_u', 'u', 'oui', '2017-04-07 12:43:25'),
('charset', 'utf-8', 'oui', '2017-04-07 12:43:25'),
('alea_ephemere_ancien', NULL, 'non', '2017-04-07 12:43:25'),
('alea_ephemere', '3f2bad9f2be2cc5098e1c9f3d4f0a4ee', 'non', '2017-04-07 12:43:25'),
('alea_ephemere_date', '1491569005', 'non', '2017-04-07 12:43:25'),
('langues_proposees', 'ar,ast,ay,bg,br,bs,ca,co,cpf,cpf_hat,cs,da,de,en,eo,es,eu,fa,fon,fr,fr_fem,gl,he,hr,hu,id,it,it_fem,ja,km,lb,my,nl,oc_auv,oc_gsc,oc_lms,oc_lnc,oc_ni,oc_ni_la,oc_ni_mis,oc_prv,oc_va,pl,pt,pt_br,ro,ru,sk,sv,tr,uk,vi,zh', 'non', '2017-04-07 12:43:25'),
('email_webmaster', 'samuel.szoniecky@univ-paris8.fr', 'oui', '2017-04-07 12:43:25'),
('nom_site', 'Mon site SPIP', 'oui', '2017-04-07 12:43:25'),
('slogan_site', '', 'oui', '2017-04-07 12:43:25'),
('adresse_site', 'http://localhost/CDNL_16-17/PROJET-PROVERB', 'non', '2017-04-07 12:43:26'),
('descriptif_site', '', 'oui', '2017-04-07 12:43:25'),
('activer_logos', 'oui', 'oui', '2017-04-07 12:43:25'),
('activer_logos_survol', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_surtitre', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_soustitre', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_descriptif', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_chapeau', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_texte', 'oui', 'oui', '2017-04-07 12:43:25'),
('articles_ps', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_redac', 'non', 'oui', '2017-04-07 12:43:25'),
('post_dates', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_urlref', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_redirection', 'non', 'oui', '2017-04-07 12:43:25'),
('creer_preview', 'non', 'non', '2017-04-07 12:43:26'),
('taille_preview', '150', 'non', '2017-04-07 12:43:26'),
('articles_modif', 'non', 'oui', '2017-04-07 12:43:25'),
('rubriques_descriptif', 'non', 'oui', '2017-04-07 12:43:25'),
('rubriques_texte', 'oui', 'oui', '2017-04-07 12:43:25'),
('accepter_inscriptions', 'non', 'oui', '2017-04-07 12:43:25'),
('accepter_visiteurs', 'non', 'oui', '2017-04-07 12:43:25'),
('prevenir_auteurs', 'non', 'oui', '2017-04-07 12:43:25'),
('suivi_edito', 'non', 'oui', '2017-04-07 12:43:25'),
('adresse_suivi', '', 'oui', '2017-04-07 12:43:25'),
('adresse_suivi_inscription', '', 'oui', '2017-04-07 12:43:25'),
('adresse_neuf', '', 'oui', '2017-04-07 12:43:25'),
('jours_neuf', '', 'oui', '2017-04-07 12:43:25'),
('quoi_de_neuf', 'non', 'oui', '2017-04-07 12:43:25'),
('preview', ',0minirezo,1comite,', 'oui', '2017-04-07 12:43:25'),
('syndication_integrale', 'oui', 'oui', '2017-04-07 12:43:25'),
('dir_img', 'IMG/', 'oui', '2017-04-07 12:43:25'),
('multi_rubriques', 'non', 'oui', '2017-04-07 12:43:25'),
('multi_secteurs', 'non', 'oui', '2017-04-07 12:43:25'),
('gerer_trad', 'non', 'oui', '2017-04-07 12:43:25'),
('langues_multilingue', '', 'oui', '2017-04-07 12:43:25'),
('version_html_max', 'html4', 'oui', '2017-04-07 12:43:25'),
('type_urls', 'page', 'oui', '2017-04-07 12:43:25'),
('email_envoi', '', 'oui', '2017-04-07 12:43:25'),
('auto_compress_http', 'non', 'oui', '2017-04-07 12:43:25'),
('mots_cles_forums', 'non', 'oui', '2017-04-07 12:43:25'),
('forums_titre', 'oui', 'oui', '2017-04-07 12:43:25'),
('forums_texte', 'oui', 'oui', '2017-04-07 12:43:25'),
('forums_urlref', 'non', 'oui', '2017-04-07 12:43:25'),
('forums_afficher_barre', 'oui', 'oui', '2017-04-07 12:43:25'),
('forums_forcer_previsu', 'oui', 'oui', '2017-04-07 12:43:25'),
('formats_documents_forum', '', 'oui', '2017-04-07 12:43:25'),
('forums_publics', 'posteriori', 'oui', '2017-04-07 12:43:25'),
('forum_prive', 'oui', 'oui', '2017-04-07 12:43:25'),
('forum_prive_objets', 'oui', 'oui', '2017-04-07 12:43:25'),
('forum_prive_admin', 'non', 'oui', '2017-04-07 12:43:25'),
('articles_mots', 'non', 'oui', '2017-04-07 12:43:25'),
('config_precise_groupes', 'non', 'oui', '2017-04-07 12:43:25'),
('messagerie_agenda', 'oui', 'oui', '2017-04-07 12:43:25'),
('barre_outils_public', 'oui', 'oui', '2017-04-07 12:43:25'),
('objets_versions', 'a:0:{}', 'oui', '2017-04-07 12:43:26'),
('activer_sites', 'non', 'oui', '2017-04-07 12:43:25'),
('proposer_sites', '0', 'oui', '2017-04-07 12:43:25'),
('activer_syndic', 'oui', 'oui', '2017-04-07 12:43:25'),
('moderation_sites', 'non', 'oui', '2017-04-07 12:43:25'),
('activer_statistiques', 'non', 'oui', '2017-04-07 12:43:25'),
('activer_captures_referers', 'non', 'oui', '2017-04-07 12:43:25'),
('activer_referers', 'oui', 'oui', '2017-04-07 12:43:25'),
('activer_breves', 'non', 'oui', '2017-04-07 12:43:25'),
('auto_compress_js', 'non', 'oui', '2017-04-07 12:43:25'),
('auto_compress_closure', 'non', 'oui', '2017-04-07 12:43:25'),
('auto_compress_css', 'non', 'oui', '2017-04-07 12:43:25'),
('url_statique_ressources', '', 'oui', '2017-04-07 12:43:25'),
('documents_objets', 'spip_articles', 'oui', '2017-04-07 12:43:25'),
('documents_date', 'non', 'oui', '2017-04-07 12:43:25'),
('langues_utilisees', 'fr', 'oui', '2017-04-07 12:43:25'),
('plugin', 'a:28:{s:4:"SPIP";a:5:{s:3:"nom";s:4:"SPIP";s:4:"etat";s:6:"stable";s:7:"version";s:5:"3.1.4";s:8:"dir_type";s:14:"_DIR_RESTREINT";s:3:"dir";s:0:"";}s:9:"COMPAGNON";a:5:{s:3:"nom";s:9:"Compagnon";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.5.2";s:3:"dir";s:9:"compagnon";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:4:"DUMP";a:5:{s:3:"nom";s:4:"Dump";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.7.5";s:3:"dir";s:4:"dump";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:6:"IMAGES";a:5:{s:3:"nom";s:6:"Images";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.2.1";s:3:"dir";s:14:"filtres_images";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:5:"FORUM";a:5:{s:3:"nom";s:5:"Forum";s:4:"etat";s:6:"stable";s:7:"version";s:6:"1.9.35";s:3:"dir";s:5:"forum";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:8:"JQUERYUI";a:5:{s:3:"nom";s:9:"jQuery UI";s:4:"etat";s:6:"stable";s:7:"version";s:6:"1.11.4";s:3:"dir";s:9:"jquery_ui";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:8:"MEDIABOX";a:5:{s:3:"nom";s:8:"MediaBox";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.0.2";s:3:"dir";s:8:"mediabox";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:4:"MOTS";a:5:{s:3:"nom";s:4:"Mots";s:4:"etat";s:6:"stable";s:7:"version";s:5:"2.7.8";s:3:"dir";s:4:"mots";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:10:"ORGANISEUR";a:5:{s:3:"nom";s:10:"Organiseur";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.0.3";s:3:"dir";s:10:"organiseur";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:9:"PETITIONS";a:5:{s:3:"nom";s:10:"Pétitions";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.5.4";s:3:"dir";s:9:"petitions";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:4:"PLAN";a:5:{s:3:"nom";s:35:"Plan du site dans l’espace privé";s:4:"etat";s:6:"stable";s:7:"version";s:5:"2.1.1";s:3:"dir";s:4:"plan";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:11:"PORTE_PLUME";a:5:{s:3:"nom";s:11:"Porte plume";s:4:"etat";s:6:"stable";s:7:"version";s:7:"1.15.14";s:3:"dir";s:11:"porte_plume";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:9:"REVISIONS";a:5:{s:3:"nom";s:10:"Révisions";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.8.8";s:3:"dir";s:9:"revisions";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:8:"SAFEHTML";a:5:{s:3:"nom";s:8:"SafeHTML";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.4.3";s:3:"dir";s:8:"safehtml";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:5:"SITES";a:5:{s:3:"nom";s:5:"Sites";s:4:"etat";s:6:"stable";s:7:"version";s:6:"1.9.24";s:3:"dir";s:5:"sites";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:23:"SQUELETTES_PAR_RUBRIQUE";a:5:{s:3:"nom";s:23:"Squelettes par Rubrique";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.1.2";s:3:"dir";s:23:"squelettes_par_rubrique";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:5:"STATS";a:5:{s:3:"nom";s:12:"Statistiques";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.0.8";s:3:"dir";s:12:"statistiques";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:3:"SVP";a:5:{s:3:"nom";s:3:"SVP";s:4:"etat";s:6:"stable";s:7:"version";s:6:"1.0.11";s:3:"dir";s:3:"svp";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:2:"TW";a:5:{s:3:"nom";s:19:"TextWheel pour SPIP";s:4:"etat";s:6:"stable";s:7:"version";s:6:"1.3.16";s:3:"dir";s:9:"textwheel";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:4:"URLS";a:5:{s:3:"nom";s:13:"Urls Etendues";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.5.9";s:3:"dir";s:13:"urls_etendues";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:9:"VERTEBRES";a:5:{s:3:"nom";s:10:"Vertèbres";s:4:"etat";s:6:"stable";s:7:"version";s:5:"1.2.6";s:3:"dir";s:9:"vertebres";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:10:"ITERATEURS";a:5:{s:3:"nom";s:10:"iterateurs";s:7:"version";s:5:"1.0.6";s:4:"etat";s:1:"?";s:8:"dir_type";s:14:"_DIR_RESTREINT";s:3:"dir";s:18:"procure:iterateurs";}s:5:"QUEUE";a:5:{s:3:"nom";s:5:"queue";s:7:"version";s:5:"0.6.8";s:4:"etat";s:1:"?";s:8:"dir_type";s:14:"_DIR_RESTREINT";s:3:"dir";s:13:"procure:queue";}s:6:"JQUERY";a:5:{s:3:"nom";s:6:"jquery";s:7:"version";s:6:"1.12.4";s:4:"etat";s:1:"?";s:8:"dir_type";s:14:"_DIR_RESTREINT";s:3:"dir";s:14:"procure:jquery";}s:3:"PHP";a:5:{s:3:"nom";s:3:"php";s:7:"version";s:6:"5.6.30";s:4:"etat";s:1:"?";s:8:"dir_type";s:14:"_DIR_RESTREINT";s:3:"dir";s:11:"procure:php";}s:6:"BREVES";a:5:{s:3:"nom";s:7:"Brèves";s:4:"etat";s:6:"stable";s:7:"version";s:6:"1.3.14";s:3:"dir";s:6:"breves";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:11:"COMPRESSEUR";a:5:{s:3:"nom";s:11:"Compresseur";s:4:"etat";s:6:"stable";s:7:"version";s:6:"1.10.4";s:3:"dir";s:11:"compresseur";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}s:6:"MEDIAS";a:5:{s:3:"nom";s:6:"Medias";s:4:"etat";s:6:"stable";s:7:"version";s:7:"2.10.38";s:3:"dir";s:6:"medias";s:8:"dir_type";s:17:"_DIR_PLUGINS_DIST";}}', 'non', '2017-04-07 12:43:26'),
('plugin_attente', 'a:0:{}', 'oui', '2017-04-07 12:43:25'),
('plugin_header', 'spip(3.1.4),compagnon(1.5.2),dump(1.7.5),images(1.2.1),forum(1.9.35),jqueryui(1.11.4),mediabox(1.0.2),mots(2.7.8),organiseur(1.0.3),petitions(1.5.4),plan(2.1.1),porte_plume(1.15.14),revisions(1.8.8),safehtml(1.4.3),sites(1.9.24),squelettes_par_rubrique(1.1.2),stats(1.0.8),svp(1.0.11),tw(1.3.16),urls(1.5.9),vertebres(1.2.6),iterateurs(1.0.6),queue(0.6.8),jquery(1.12.4),php(5.6.30),breves(1.3.14),compresseur(1.10.4),medias(2.10.38)', 'non', '2017-04-07 12:43:26'),
('compagnon', 'a:2:{s:6:"config";a:1:{s:7:"activer";s:3:"oui";}i:1;a:3:{s:7:"accueil";i:1;s:18:"accueil_configurer";i:1;s:19:"accueil_publication";i:1;}}', 'oui', '2017-04-07 12:43:33'),
('compagnon_base_version', '1.0.0', 'oui', '2017-04-07 12:43:26'),
('forum_base_version', '1.2.2', 'oui', '2017-04-07 12:43:26'),
('mots_base_version', '2.1.1', 'oui', '2017-04-07 12:43:26'),
('organiseur_base_version', '1.1.2', 'oui', '2017-04-07 12:43:26'),
('petitions_base_version', '1.1.6', 'oui', '2017-04-07 12:43:26'),
('revisions_base_version', '1.2.0', 'oui', '2017-04-07 12:43:26'),
('sites_base_version', '1.1.1', 'oui', '2017-04-07 12:43:26'),
('stats_base_version', '1.0.1', 'oui', '2017-04-07 12:43:26'),
('svp_base_version', '0.5.1', 'oui', '2017-04-07 12:43:26'),
('urls_base_version', '1.1.4', 'oui', '2017-04-07 12:43:26'),
('breves_base_version', '1.0.0', 'oui', '2017-04-07 12:43:26'),
('medias_base_version', '1.2.7', 'oui', '2017-04-07 12:43:26'),
('plugin_installes', 'a:12:{i:0;s:9:"compagnon";i:1;s:5:"forum";i:2;s:4:"mots";i:3;s:10:"organiseur";i:4;s:9:"petitions";i:5;s:9:"revisions";i:6;s:5:"sites";i:7;s:12:"statistiques";i:8;s:3:"svp";i:9;s:13:"urls_etendues";i:10;s:6:"breves";i:11;s:6:"medias";}', 'oui', '2017-04-07 12:43:26'),
('cache_signature', '3580b4ac34ec23a6461a395842b8618b4689960b48002413d1e805aeacf1d696', 'oui', '2017-04-07 12:43:28'),
('secret_du_site', 'e386042f7e0a83ad23e8bb7aac30bca9dc87a84ab0327b42bbeac239186fb258', 'oui', '2017-04-07 12:43:29');

-- --------------------------------------------------------

--
-- Structure de la table `spip_mots`
--

DROP TABLE IF EXISTS `spip_mots`;
CREATE TABLE `spip_mots` (
  `id_mot` bigint(21) NOT NULL,
  `titre` text NOT NULL,
  `descriptif` text NOT NULL,
  `texte` longtext NOT NULL,
  `id_groupe` bigint(21) NOT NULL DEFAULT '0',
  `type` text NOT NULL,
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_mots_liens`
--

DROP TABLE IF EXISTS `spip_mots_liens`;
CREATE TABLE `spip_mots_liens` (
  `id_mot` bigint(21) NOT NULL DEFAULT '0',
  `id_objet` bigint(21) NOT NULL DEFAULT '0',
  `objet` varchar(25) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_paquets`
--

DROP TABLE IF EXISTS `spip_paquets`;
CREATE TABLE `spip_paquets` (
  `id_paquet` bigint(21) NOT NULL,
  `id_plugin` bigint(21) NOT NULL,
  `prefixe` varchar(30) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `version` varchar(24) NOT NULL DEFAULT '',
  `version_base` varchar(24) NOT NULL DEFAULT '',
  `compatibilite_spip` varchar(24) NOT NULL DEFAULT '',
  `branches_spip` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `auteur` text NOT NULL,
  `credit` text NOT NULL,
  `licence` text NOT NULL,
  `copyright` text NOT NULL,
  `lien_doc` text NOT NULL,
  `lien_demo` text NOT NULL,
  `lien_dev` text NOT NULL,
  `etat` varchar(16) NOT NULL DEFAULT '',
  `etatnum` int(1) NOT NULL DEFAULT '0',
  `dependances` text NOT NULL,
  `procure` text NOT NULL,
  `date_crea` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modif` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `id_depot` bigint(21) NOT NULL DEFAULT '0',
  `nom_archive` varchar(255) NOT NULL DEFAULT '',
  `nbo_archive` int(11) NOT NULL DEFAULT '0',
  `maj_archive` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `src_archive` varchar(255) NOT NULL DEFAULT '',
  `traductions` text NOT NULL,
  `actif` varchar(3) NOT NULL DEFAULT 'non',
  `installe` varchar(3) NOT NULL DEFAULT 'non',
  `recent` int(2) NOT NULL DEFAULT '0',
  `maj_version` varchar(255) NOT NULL DEFAULT '',
  `superieur` varchar(3) NOT NULL DEFAULT 'non',
  `obsolete` varchar(3) NOT NULL DEFAULT 'non',
  `attente` varchar(3) NOT NULL DEFAULT 'non',
  `constante` varchar(30) NOT NULL DEFAULT '',
  `signature` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_petitions`
--

DROP TABLE IF EXISTS `spip_petitions`;
CREATE TABLE `spip_petitions` (
  `id_petition` bigint(21) NOT NULL,
  `id_article` bigint(21) NOT NULL DEFAULT '0',
  `email_unique` char(3) NOT NULL DEFAULT '',
  `site_obli` char(3) NOT NULL DEFAULT '',
  `site_unique` char(3) NOT NULL DEFAULT '',
  `message` char(3) NOT NULL DEFAULT '',
  `texte` longtext NOT NULL,
  `statut` varchar(10) NOT NULL DEFAULT 'publie',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_plugins`
--

DROP TABLE IF EXISTS `spip_plugins`;
CREATE TABLE `spip_plugins` (
  `id_plugin` bigint(21) NOT NULL,
  `prefixe` varchar(30) NOT NULL DEFAULT '',
  `nom` text NOT NULL,
  `slogan` text NOT NULL,
  `categorie` varchar(100) NOT NULL DEFAULT '',
  `tags` text NOT NULL,
  `vmax` varchar(24) NOT NULL DEFAULT '',
  `date_crea` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modif` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `compatibilite_spip` varchar(24) NOT NULL DEFAULT '',
  `branches_spip` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_referers`
--

DROP TABLE IF EXISTS `spip_referers`;
CREATE TABLE `spip_referers` (
  `referer_md5` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `visites` int(10) UNSIGNED NOT NULL,
  `visites_jour` int(10) UNSIGNED NOT NULL,
  `visites_veille` int(10) UNSIGNED NOT NULL,
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_referers_articles`
--

DROP TABLE IF EXISTS `spip_referers_articles`;
CREATE TABLE `spip_referers_articles` (
  `id_article` int(10) UNSIGNED NOT NULL,
  `referer_md5` bigint(20) UNSIGNED NOT NULL,
  `referer` varchar(255) NOT NULL DEFAULT '',
  `visites` int(10) UNSIGNED NOT NULL,
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_resultats`
--

DROP TABLE IF EXISTS `spip_resultats`;
CREATE TABLE `spip_resultats` (
  `recherche` char(16) NOT NULL DEFAULT '',
  `id` int(10) UNSIGNED NOT NULL,
  `points` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `table_objet` varchar(30) NOT NULL DEFAULT '',
  `serveur` char(16) NOT NULL DEFAULT '',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_rubriques`
--

DROP TABLE IF EXISTS `spip_rubriques`;
CREATE TABLE `spip_rubriques` (
  `id_rubrique` bigint(21) NOT NULL,
  `id_parent` bigint(21) NOT NULL DEFAULT '0',
  `titre` text NOT NULL,
  `descriptif` text NOT NULL,
  `texte` longtext NOT NULL,
  `id_secteur` bigint(21) NOT NULL DEFAULT '0',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `statut` varchar(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lang` varchar(10) NOT NULL DEFAULT '',
  `langue_choisie` varchar(3) DEFAULT 'non',
  `statut_tmp` varchar(10) NOT NULL DEFAULT '0',
  `date_tmp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `profondeur` smallint(5) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_signatures`
--

DROP TABLE IF EXISTS `spip_signatures`;
CREATE TABLE `spip_signatures` (
  `id_signature` bigint(21) NOT NULL,
  `id_petition` bigint(21) NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nom_email` text NOT NULL,
  `ad_email` text NOT NULL,
  `nom_site` text NOT NULL,
  `url_site` text NOT NULL,
  `message` mediumtext NOT NULL,
  `statut` varchar(10) NOT NULL DEFAULT '0',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_syndic`
--

DROP TABLE IF EXISTS `spip_syndic`;
CREATE TABLE `spip_syndic` (
  `id_syndic` bigint(21) NOT NULL,
  `id_rubrique` bigint(21) NOT NULL DEFAULT '0',
  `id_secteur` bigint(21) NOT NULL DEFAULT '0',
  `nom_site` text NOT NULL,
  `url_site` text NOT NULL,
  `url_syndic` text NOT NULL,
  `descriptif` text NOT NULL,
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `syndication` varchar(3) NOT NULL DEFAULT '',
  `statut` varchar(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_syndic` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_index` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `moderation` varchar(3) DEFAULT 'non',
  `miroir` varchar(3) DEFAULT 'non',
  `oubli` varchar(3) DEFAULT 'non',
  `resume` varchar(3) DEFAULT 'oui'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_syndic_articles`
--

DROP TABLE IF EXISTS `spip_syndic_articles`;
CREATE TABLE `spip_syndic_articles` (
  `id_syndic_article` bigint(21) NOT NULL,
  `id_syndic` bigint(21) NOT NULL DEFAULT '0',
  `titre` text NOT NULL,
  `url` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lesauteurs` text NOT NULL,
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `statut` varchar(10) NOT NULL DEFAULT '0',
  `descriptif` text NOT NULL,
  `lang` varchar(10) NOT NULL DEFAULT '',
  `url_source` tinytext NOT NULL,
  `source` tinytext NOT NULL,
  `tags` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_types_documents`
--

DROP TABLE IF EXISTS `spip_types_documents`;
CREATE TABLE `spip_types_documents` (
  `extension` varchar(10) NOT NULL DEFAULT '',
  `titre` text NOT NULL,
  `descriptif` text NOT NULL,
  `mime_type` varchar(100) NOT NULL DEFAULT '',
  `inclus` enum('non','image','embed') NOT NULL DEFAULT 'non',
  `upload` enum('oui','non') NOT NULL DEFAULT 'oui',
  `media_defaut` varchar(10) NOT NULL DEFAULT 'file',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `spip_types_documents`
--

INSERT INTO `spip_types_documents` (`extension`, `titre`, `descriptif`, `mime_type`, `inclus`, `upload`, `media_defaut`, `maj`) VALUES
('jpg', 'JPEG', '', 'image/jpeg', 'image', 'oui', 'image', '2017-04-07 12:43:26'),
('png', 'PNG', '', 'image/png', 'image', 'oui', 'image', '2017-04-07 12:43:26'),
('gif', 'GIF', '', 'image/gif', 'image', 'oui', 'image', '2017-04-07 12:43:26'),
('bmp', 'BMP', '', 'image/x-ms-bmp', 'image', 'oui', 'image', '2017-04-07 12:43:26'),
('tif', 'TIFF', '', 'image/tiff', 'embed', 'oui', 'image', '2017-04-07 12:43:26'),
('aac', 'Advanced Audio Coding', '', 'audio/mp4a-latm', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('ac3', 'AC-3 Compressed Audio', '', 'audio/x-aac', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('aifc', 'Compressed AIFF Audio', '', 'audio/x-aifc', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('aiff', 'AIFF', '', 'audio/x-aiff', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('amr', 'Adaptive Multi-Rate Audio', '', 'audio/amr', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('ape', 'Monkey\'s Audio File', '', 'audio/x-monkeys-audio', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('asf', 'Windows Media', '', 'video/x-ms-asf', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('avi', 'AVI', '', 'video/x-msvideo', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('anx', 'Annodex', '', 'application/annodex', 'embed', 'oui', 'file', '2017-04-07 12:43:26'),
('axa', 'Annodex Audio', '', 'audio/annodex', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('axv', 'Annodex Video', '', 'video/annodex', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('dv', 'Digital Video', '', 'video/x-dv', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('f4a', 'Audio for Adobe Flash Player', '', 'audio/mp4', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('f4b', 'Audio Book for Adobe Flash Player', '', 'audio/mp4', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('f4p', 'Protected Video for Adobe Flash Player', '', 'video/mp4', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('f4v', 'Video for Adobe Flash Player', '', 'video/mp4', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('flac', 'Free Lossless Audio Codec', '', 'audio/x-flac', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('flv', 'Flash Video', '', 'video/x-flv', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('m2p', 'MPEG-PS', '', 'video/MP2P', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('m2ts', 'BDAV MPEG-2 Transport Stream', '', 'video/MP2T', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('m4a', 'MPEG4 Audio', '', 'audio/mp4a-latm', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('m4b', 'MPEG4 Audio', '', 'audio/mp4a-latm', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('m4p', 'MPEG4 Audio', '', 'audio/mp4a-latm', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('m4r', 'iPhone Ringtone', '', 'audio/aac', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('m4u', 'MPEG4 Playlist', '', 'video/vnd.mpegurl', 'non', 'oui', 'video', '2017-04-07 12:43:26'),
('m4v', 'MPEG4 Video', '', 'video/x-m4v', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('mid', 'Midi', '', 'audio/midi', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('mka', 'Matroska Audio', '', 'audio/mka', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('mkv', 'Matroska Video', '', 'video/mkv', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('mng', 'MNG', '', 'video/x-mng', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('mov', 'QuickTime', '', 'video/quicktime', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('mp3', 'MP3', '', 'audio/mpeg', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('mp4', 'MPEG4', '', 'application/mp4', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('mpc', 'Musepack', '', 'audio/x-musepack', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('mpg', 'MPEG', '', 'video/mpeg', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('mts', 'AVCHD MPEG-2 transport stream', '', 'video/MP2T', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('oga', 'Ogg Audio', '', 'audio/ogg', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('ogg', 'Ogg Vorbis', '', 'audio/ogg', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('ogv', 'Ogg Video', '', 'video/ogg', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('ogx', 'Ogg Multiplex', '', 'application/ogg', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('qt', 'QuickTime', '', 'video/quicktime', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('ra', 'RealAudio', '', 'audio/x-pn-realaudio', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('ram', 'RealAudio', '', 'audio/x-pn-realaudio', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('rm', 'RealAudio', '', 'audio/x-pn-realaudio', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('spx', 'Ogg Speex', '', 'audio/ogg', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('svg', 'Scalable Vector Graphics', '', 'image/svg+xml', 'embed', 'oui', 'image', '2017-04-07 12:43:26'),
('svgz', 'Compressed Scalable Vector Graphic', '', 'image/svg+xml', 'embed', 'oui', 'image', '2017-04-07 12:43:26'),
('swf', 'Flash', '', 'application/x-shockwave-flash', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('ts', 'MPEG transport stream', '', 'video/MP2T', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('wav', 'WAV', '', 'audio/x-wav', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('webm', 'WebM', '', 'video/webm', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('wma', 'Windows Media Audio', '', 'audio/x-ms-wma', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('wmv', 'Windows Media Video', '', 'video/x-ms-wmv', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('y4m', 'YUV4MPEG2', '', 'video/x-raw-yuv', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('3gp', '3rd Generation Partnership Project', '', 'video/3gpp', 'embed', 'oui', 'video', '2017-04-07 12:43:26'),
('3ga', '3GP Audio File', '', 'audio/3ga', 'embed', 'oui', 'audio', '2017-04-07 12:43:26'),
('7z', '7 Zip', '', 'application/x-7z-compressed', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ai', 'Adobe Illustrator', '', 'application/illustrator', 'non', 'oui', 'image', '2017-04-07 12:43:26'),
('abw', 'Abiword', '', 'application/abiword', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('asx', 'Advanced Stream Redirector', '', 'video/x-ms-asf', 'non', 'oui', 'video', '2017-04-07 12:43:26'),
('bib', 'BibTeX', '', 'application/x-bibtex', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('bin', 'Binary Data', '', 'application/octet-stream', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('blend', 'Blender', '', 'application/x-blender', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('bz2', 'BZip', '', 'application/x-bzip2', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('c', 'C source', '', 'text/x-csrc', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('csl', 'Citation Style Language', '', 'application/xml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('css', 'Cascading Style Sheet', '', 'text/css', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('csv', 'Comma Separated Values', '', 'text/csv', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('deb', 'Debian', '', 'application/x-debian-package', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('doc', 'Word', '', 'application/msword', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('dot', 'Word Template', '', 'application/msword', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('djvu', 'DjVu', '', 'image/vnd.djvu', 'non', 'oui', 'image', '2017-04-07 12:43:26'),
('dvi', 'LaTeX DVI', '', 'application/x-dvi', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('emf', 'Enhanced Metafile', '', 'image/x-emf', 'non', 'oui', 'image', '2017-04-07 12:43:26'),
('enl', 'EndNote Library', '', 'application/octet-stream', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ens', 'EndNote Style', '', 'application/octet-stream', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('eps', 'PostScript', '', 'application/postscript', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('epub', 'EPUB', '', 'application/epub+zip', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('gpx', 'GPS eXchange Format', '', 'application/gpx+xml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('gz', 'GZ', '', 'application/x-gzip', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('h', 'C header', '', 'text/x-chdr', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('html', 'HTML', '', 'text/html', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ics', 'iCalendar', '', 'text/calendar', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('jar', 'Java Archive', '', 'application/java-archive', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('json', 'JSON', '', 'application/json', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('kml', 'Keyhole Markup Language', '', 'application/vnd.google-earth.kml+xml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('kmz', 'Google Earth Placemark File', '', 'application/vnd.google-earth.kmz', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('lyx', 'Lyx file', '', 'application/x-lyx', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('m3u', 'M3U Playlist', '', 'text/plain', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('m3u8', 'M3U8 Playlist', '', 'text/plain', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('mathml', 'MathML', '', 'application/mathml+xml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('mbtiles', 'MBTiles', '', 'application/x-sqlite3', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('md', 'Markdown Document', '', 'text/x-markdown', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('pas', 'Pascal', '', 'text/x-pascal', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('pdf', 'PDF', '', 'application/pdf', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('pgn', 'Portable Game Notation', '', 'application/x-chess-pgn', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('pls', 'Playlist', '', 'text/plain', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ppt', 'PowerPoint', '', 'application/vnd.ms-powerpoint', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('pot', 'PowerPoint Template', '', 'application/vnd.ms-powerpoint', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ps', 'PostScript', '', 'application/postscript', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('psd', 'Photoshop', '', 'image/x-photoshop', 'non', 'oui', 'image', '2017-04-07 12:43:26'),
('rar', 'WinRAR', '', 'application/x-rar-compressed', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('rdf', 'Resource Description Framework', '', 'application/rdf+xml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ris', 'RIS', '', 'application/x-research-info-systems', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('rpm', 'RedHat/Mandrake/SuSE', '', 'application/x-redhat-package-manager', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('rtf', 'RTF', '', 'application/rtf', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sdc', 'StarOffice Spreadsheet', '', 'application/vnd.stardivision.calc', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sdd', 'StarOffice Presentation', '', 'application/vnd.stardivision.impress', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sdw', 'StarOffice Writer document', '', 'application/vnd.stardivision.writer', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sit', 'Stuffit', '', 'application/x-stuffit', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sla', 'Scribus', '', 'application/x-scribus', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('srt', 'SubRip Subtitle', '', 'text/plain', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ssa', 'SubStation Alpha Subtitle', '', 'text/plain', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sxc', 'OpenOffice.org Calc', '', 'application/vnd.sun.xml.calc', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sxi', 'OpenOffice.org Impress', '', 'application/vnd.sun.xml.impress', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sxw', 'OpenOffice.org', '', 'application/vnd.sun.xml.writer', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('tar', 'Tar', '', 'application/x-tar', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('tex', 'LaTeX', '', 'text/x-tex', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('tgz', 'TGZ', '', 'application/x-gtar', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('torrent', 'BitTorrent', '', 'application/x-bittorrent', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ttf', 'TTF Font', '', 'application/x-font-ttf', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('txt', 'Texte', '', 'text/plain', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('usf', 'Universal Subtitle Format', '', 'application/xml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('vcf', 'vCard', '', 'text/vcard', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xcf', 'GIMP multi-layer', '', 'application/x-xcf', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xls', 'Excel', '', 'application/vnd.ms-excel', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xlt', 'Excel Template', '', 'application/vnd.ms-excel', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('wmf', 'Windows Metafile', '', 'image/x-emf', 'non', 'oui', 'image', '2017-04-07 12:43:26'),
('wpl', 'Windows Media Player Playlist', '', 'application/vnd.ms-wpl', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xspf', 'XSPF', '', 'application/xspf+xml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xml', 'XML', '', 'application/xml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('yaml', 'YAML', '', 'text/yaml', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('zip', 'Zip', '', 'application/zip', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('odt', 'OpenDocument Text', '', 'application/vnd.oasis.opendocument.text', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ods', 'OpenDocument Spreadsheet', '', 'application/vnd.oasis.opendocument.spreadsheet', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('odp', 'OpenDocument Presentation', '', 'application/vnd.oasis.opendocument.presentation', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('odg', 'OpenDocument Graphics', '', 'application/vnd.oasis.opendocument.graphics', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('odc', 'OpenDocument Chart', '', 'application/vnd.oasis.opendocument.chart', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('odf', 'OpenDocument Formula', '', 'application/vnd.oasis.opendocument.formula', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('odb', 'OpenDocument Database', '', 'application/vnd.oasis.opendocument.database', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('odi', 'OpenDocument Image', '', 'application/vnd.oasis.opendocument.image', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('odm', 'OpenDocument Text-master', '', 'application/vnd.oasis.opendocument.text-master', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ott', 'OpenDocument Text-template', '', 'application/vnd.oasis.opendocument.text-template', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ots', 'OpenDocument Spreadsheet-template', '', 'application/vnd.oasis.opendocument.spreadsheet-template', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('otp', 'OpenDocument Presentation-template', '', 'application/vnd.oasis.opendocument.presentation-template', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('otg', 'OpenDocument Graphics-template', '', 'application/vnd.oasis.opendocument.graphics-template', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('cls', 'LaTeX Class', '', 'text/x-tex', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('sty', 'LaTeX Style Sheet', '', 'text/x-tex', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('docm', 'Word', '', 'application/vnd.ms-word.document.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('docx', 'Word', '', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('dotm', 'Word template', '', 'application/vnd.ms-word.template.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('dotx', 'Word template', '', 'application/vnd.openxmlformats-officedocument.wordprocessingml.template', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('potm', 'Powerpoint template', '', 'application/vnd.ms-powerpoint.template.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('potx', 'Powerpoint template', '', 'application/vnd.openxmlformats-officedocument.presentationml.template', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ppam', 'Powerpoint addin', '', 'application/vnd.ms-powerpoint.addin.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ppsm', 'Powerpoint slideshow', '', 'application/vnd.ms-powerpoint.slideshow.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('ppsx', 'Powerpoint slideshow', '', 'application/vnd.openxmlformats-officedocument.presentationml.slideshow', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('pptm', 'Powerpoint', '', 'application/vnd.ms-powerpoint.presentation.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('pptx', 'Powerpoint', '', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xlam', 'Excel', '', 'application/vnd.ms-excel.addin.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xlsb', 'Excel binary', '', 'application/vnd.ms-excel.sheet.binary.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xlsm', 'Excel', '', 'application/vnd.ms-excel.sheet.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xlsx', 'Excel', '', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xltm', 'Excel template', '', 'application/vnd.ms-excel.template.macroEnabled.12', 'non', 'oui', 'file', '2017-04-07 12:43:26'),
('xltx', 'Excel template', '', 'application/vnd.openxmlformats-officedocument.spreadsheetml.template', 'non', 'oui', 'file', '2017-04-07 12:43:26');

-- --------------------------------------------------------

--
-- Structure de la table `spip_urls`
--

DROP TABLE IF EXISTS `spip_urls`;
CREATE TABLE `spip_urls` (
  `id_parent` bigint(21) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `type` varchar(25) NOT NULL DEFAULT 'article',
  `id_objet` bigint(21) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `segments` smallint(3) NOT NULL DEFAULT '1',
  `perma` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_versions`
--

DROP TABLE IF EXISTS `spip_versions`;
CREATE TABLE `spip_versions` (
  `id_version` bigint(21) NOT NULL DEFAULT '0',
  `id_objet` bigint(21) NOT NULL DEFAULT '0',
  `objet` varchar(25) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `id_auteur` varchar(23) NOT NULL DEFAULT '',
  `titre_version` text NOT NULL,
  `permanent` char(3) NOT NULL DEFAULT '',
  `champs` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_versions_fragments`
--

DROP TABLE IF EXISTS `spip_versions_fragments`;
CREATE TABLE `spip_versions_fragments` (
  `id_fragment` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `version_min` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `version_max` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `id_objet` bigint(21) NOT NULL,
  `objet` varchar(25) NOT NULL DEFAULT '',
  `compress` tinyint(4) NOT NULL,
  `fragment` longblob
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_visites`
--

DROP TABLE IF EXISTS `spip_visites`;
CREATE TABLE `spip_visites` (
  `date` date NOT NULL,
  `visites` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `spip_visites_articles`
--

DROP TABLE IF EXISTS `spip_visites_articles`;
CREATE TABLE `spip_visites_articles` (
  `date` date NOT NULL,
  `id_article` int(10) UNSIGNED NOT NULL,
  `visites` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `spip_articles`
--
ALTER TABLE `spip_articles`
  ADD PRIMARY KEY (`id_article`),
  ADD KEY `id_rubrique` (`id_rubrique`),
  ADD KEY `id_secteur` (`id_secteur`),
  ADD KEY `id_trad` (`id_trad`),
  ADD KEY `lang` (`lang`),
  ADD KEY `statut` (`statut`,`date`);

--
-- Index pour la table `spip_auteurs`
--
ALTER TABLE `spip_auteurs`
  ADD PRIMARY KEY (`id_auteur`),
  ADD KEY `login` (`login`),
  ADD KEY `statut` (`statut`),
  ADD KEY `en_ligne` (`en_ligne`);

--
-- Index pour la table `spip_auteurs_liens`
--
ALTER TABLE `spip_auteurs_liens`
  ADD PRIMARY KEY (`id_auteur`,`id_objet`,`objet`),
  ADD KEY `id_auteur` (`id_auteur`),
  ADD KEY `id_objet` (`id_objet`),
  ADD KEY `objet` (`objet`);

--
-- Index pour la table `spip_breves`
--
ALTER TABLE `spip_breves`
  ADD PRIMARY KEY (`id_breve`),
  ADD KEY `id_rubrique` (`id_rubrique`);

--
-- Index pour la table `spip_depots`
--
ALTER TABLE `spip_depots`
  ADD PRIMARY KEY (`id_depot`);

--
-- Index pour la table `spip_depots_plugins`
--
ALTER TABLE `spip_depots_plugins`
  ADD PRIMARY KEY (`id_depot`,`id_plugin`);

--
-- Index pour la table `spip_documents`
--
ALTER TABLE `spip_documents`
  ADD PRIMARY KEY (`id_document`),
  ADD KEY `id_vignette` (`id_vignette`),
  ADD KEY `mode` (`mode`),
  ADD KEY `extension` (`extension`);

--
-- Index pour la table `spip_documents_liens`
--
ALTER TABLE `spip_documents_liens`
  ADD PRIMARY KEY (`id_document`,`id_objet`,`objet`),
  ADD KEY `id_document` (`id_document`),
  ADD KEY `id_objet` (`id_objet`),
  ADD KEY `objet` (`objet`);

--
-- Index pour la table `spip_forum`
--
ALTER TABLE `spip_forum`
  ADD PRIMARY KEY (`id_forum`),
  ADD KEY `id_auteur` (`id_auteur`),
  ADD KEY `id_parent` (`id_parent`),
  ADD KEY `id_thread` (`id_thread`),
  ADD KEY `optimal` (`statut`,`id_parent`,`id_objet`,`objet`,`date_heure`);

--
-- Index pour la table `spip_groupes_mots`
--
ALTER TABLE `spip_groupes_mots`
  ADD PRIMARY KEY (`id_groupe`);

--
-- Index pour la table `spip_jobs`
--
ALTER TABLE `spip_jobs`
  ADD PRIMARY KEY (`id_job`),
  ADD KEY `date` (`date`),
  ADD KEY `status` (`status`);

--
-- Index pour la table `spip_jobs_liens`
--
ALTER TABLE `spip_jobs_liens`
  ADD PRIMARY KEY (`id_job`,`id_objet`,`objet`),
  ADD KEY `id_job` (`id_job`);

--
-- Index pour la table `spip_messages`
--
ALTER TABLE `spip_messages`
  ADD PRIMARY KEY (`id_message`),
  ADD KEY `id_auteur` (`id_auteur`);

--
-- Index pour la table `spip_meta`
--
ALTER TABLE `spip_meta`
  ADD PRIMARY KEY (`nom`);

--
-- Index pour la table `spip_mots`
--
ALTER TABLE `spip_mots`
  ADD PRIMARY KEY (`id_mot`),
  ADD KEY `id_groupe` (`id_groupe`);

--
-- Index pour la table `spip_mots_liens`
--
ALTER TABLE `spip_mots_liens`
  ADD PRIMARY KEY (`id_mot`,`id_objet`,`objet`),
  ADD KEY `id_mot` (`id_mot`),
  ADD KEY `id_objet` (`id_objet`),
  ADD KEY `objet` (`objet`);

--
-- Index pour la table `spip_paquets`
--
ALTER TABLE `spip_paquets`
  ADD PRIMARY KEY (`id_paquet`),
  ADD KEY `id_plugin` (`id_plugin`);

--
-- Index pour la table `spip_petitions`
--
ALTER TABLE `spip_petitions`
  ADD PRIMARY KEY (`id_petition`),
  ADD UNIQUE KEY `id_article` (`id_article`);

--
-- Index pour la table `spip_plugins`
--
ALTER TABLE `spip_plugins`
  ADD PRIMARY KEY (`id_plugin`),
  ADD KEY `prefixe` (`prefixe`);

--
-- Index pour la table `spip_referers`
--
ALTER TABLE `spip_referers`
  ADD PRIMARY KEY (`referer_md5`);

--
-- Index pour la table `spip_referers_articles`
--
ALTER TABLE `spip_referers_articles`
  ADD PRIMARY KEY (`id_article`,`referer_md5`),
  ADD KEY `referer_md5` (`referer_md5`);

--
-- Index pour la table `spip_rubriques`
--
ALTER TABLE `spip_rubriques`
  ADD PRIMARY KEY (`id_rubrique`),
  ADD KEY `lang` (`lang`),
  ADD KEY `id_parent` (`id_parent`);

--
-- Index pour la table `spip_signatures`
--
ALTER TABLE `spip_signatures`
  ADD PRIMARY KEY (`id_signature`),
  ADD KEY `id_petition` (`id_petition`),
  ADD KEY `statut` (`statut`);

--
-- Index pour la table `spip_syndic`
--
ALTER TABLE `spip_syndic`
  ADD PRIMARY KEY (`id_syndic`),
  ADD KEY `id_rubrique` (`id_rubrique`),
  ADD KEY `id_secteur` (`id_secteur`),
  ADD KEY `statut` (`statut`,`date_syndic`);

--
-- Index pour la table `spip_syndic_articles`
--
ALTER TABLE `spip_syndic_articles`
  ADD PRIMARY KEY (`id_syndic_article`),
  ADD KEY `id_syndic` (`id_syndic`),
  ADD KEY `statut` (`statut`),
  ADD KEY `url` (`url`(255));

--
-- Index pour la table `spip_types_documents`
--
ALTER TABLE `spip_types_documents`
  ADD PRIMARY KEY (`extension`),
  ADD KEY `inclus` (`inclus`);

--
-- Index pour la table `spip_urls`
--
ALTER TABLE `spip_urls`
  ADD PRIMARY KEY (`id_parent`,`url`),
  ADD KEY `type` (`type`,`id_objet`);

--
-- Index pour la table `spip_versions`
--
ALTER TABLE `spip_versions`
  ADD PRIMARY KEY (`id_version`,`id_objet`,`objet`),
  ADD KEY `id_version` (`id_version`),
  ADD KEY `id_objet` (`id_objet`),
  ADD KEY `objet` (`objet`);

--
-- Index pour la table `spip_versions_fragments`
--
ALTER TABLE `spip_versions_fragments`
  ADD PRIMARY KEY (`id_objet`,`objet`,`id_fragment`,`version_min`);

--
-- Index pour la table `spip_visites`
--
ALTER TABLE `spip_visites`
  ADD PRIMARY KEY (`date`);

--
-- Index pour la table `spip_visites_articles`
--
ALTER TABLE `spip_visites_articles`
  ADD PRIMARY KEY (`date`,`id_article`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `spip_articles`
--
ALTER TABLE `spip_articles`
  MODIFY `id_article` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_auteurs`
--
ALTER TABLE `spip_auteurs`
  MODIFY `id_auteur` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `spip_breves`
--
ALTER TABLE `spip_breves`
  MODIFY `id_breve` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_depots`
--
ALTER TABLE `spip_depots`
  MODIFY `id_depot` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_documents`
--
ALTER TABLE `spip_documents`
  MODIFY `id_document` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_forum`
--
ALTER TABLE `spip_forum`
  MODIFY `id_forum` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_groupes_mots`
--
ALTER TABLE `spip_groupes_mots`
  MODIFY `id_groupe` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_jobs`
--
ALTER TABLE `spip_jobs`
  MODIFY `id_job` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `spip_messages`
--
ALTER TABLE `spip_messages`
  MODIFY `id_message` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_mots`
--
ALTER TABLE `spip_mots`
  MODIFY `id_mot` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_paquets`
--
ALTER TABLE `spip_paquets`
  MODIFY `id_paquet` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_petitions`
--
ALTER TABLE `spip_petitions`
  MODIFY `id_petition` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_plugins`
--
ALTER TABLE `spip_plugins`
  MODIFY `id_plugin` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_rubriques`
--
ALTER TABLE `spip_rubriques`
  MODIFY `id_rubrique` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_signatures`
--
ALTER TABLE `spip_signatures`
  MODIFY `id_signature` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_syndic`
--
ALTER TABLE `spip_syndic`
  MODIFY `id_syndic` bigint(21) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spip_syndic_articles`
--
ALTER TABLE `spip_syndic_articles`
  MODIFY `id_syndic_article` bigint(21) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
